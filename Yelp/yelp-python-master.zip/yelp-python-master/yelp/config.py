API_HOST = 'api.yelp.com'
BUSINESS_PATH = '/v2/business/'
PHONE_SEARCH_PATH = '/v2/phone_search/'
SEARCH_PATH = '/v2/search/'
